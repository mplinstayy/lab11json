package com.example.jsonphonebook

data class PhoneBook(
    var name: String,
    var phone: Number
) {
}